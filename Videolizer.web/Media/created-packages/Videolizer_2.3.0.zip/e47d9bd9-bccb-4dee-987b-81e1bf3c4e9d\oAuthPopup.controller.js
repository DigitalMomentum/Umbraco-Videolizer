﻿angular.module('umbraco')
    .controller('DigitalMomentum.Videolizer.oAuthPopup',
        function ($scope) {
          //Nothing to do here
        }
    );